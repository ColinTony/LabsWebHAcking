Investiga subdominios y rutas. Busca flags.
