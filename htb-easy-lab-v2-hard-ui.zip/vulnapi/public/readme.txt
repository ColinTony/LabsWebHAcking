Explora /api/view?file=readme.txt
